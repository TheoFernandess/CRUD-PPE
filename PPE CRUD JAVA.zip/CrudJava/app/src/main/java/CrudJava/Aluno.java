package CrudJava;

public class Aluno extends Pessoa {
    private String matricula;

    // Construtor
    public Aluno(String nome, String dataNascimento, String matricula, String email, String telefone, String endereco) {
        super(nome, dataNascimento, email, telefone, endereco);
        this.matricula = matricula;
    }

    // Getters e Setters
    public String getMatricula() {
        return matricula;
    }

    public void setMatricula(String matricula) {
        this.matricula = matricula; 
    }
}
