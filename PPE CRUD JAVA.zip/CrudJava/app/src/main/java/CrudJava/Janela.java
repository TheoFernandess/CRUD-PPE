package CrudJava;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.regex.Pattern;

public class Janela extends JFrame {

    private ArrayList<Aluno> alunos = new ArrayList<>();
    private JTextArea textArea;

    public Janela() {
        setTitle("Sistema CRUD de Cadastro Escolar");
        setSize(600, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel panel = new JPanel();
        panel.setLayout(null);
        add(panel);

        JButton btnCadastro = new JButton("Cadastrar");
        btnCadastro.setBounds(20, 20, 120, 30);
        panel.add(btnCadastro);

        JButton btnExibir = new JButton("Exibir");
        btnExibir.setBounds(160, 20, 120, 30);
        panel.add(btnExibir);

        JButton btnEditar = new JButton("Editar");
        btnEditar.setBounds(300, 20, 120, 30);
        panel.add(btnEditar);

        JButton btnExcluir = new JButton("Excluir");
        btnExcluir.setBounds(440, 20, 120, 30);
        panel.add(btnExcluir);

        textArea = new JTextArea();
        textArea.setBounds(20, 70, 540, 280);
        panel.add(textArea);

        btnCadastro.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                cadastrarAluno();
            }
        });

        btnExibir.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                exibirAlunos();
            }
        });

        btnEditar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                editarAluno();
            }
        });

        btnExcluir.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                excluirAluno();
            }
        });
    }

    private void cadastrarAluno() {
        String nome = JOptionPane.showInputDialog("Nome Completo:");
        String dataNascimento = JOptionPane.showInputDialog("Data de Nascimento:");
        String matricula = JOptionPane.showInputDialog("Número de Matrícula:");
        String email = JOptionPane.showInputDialog("E-mail:");
        String telefone = JOptionPane.showInputDialog("Telefone:");
        String endereco = JOptionPane.showInputDialog("Endereço:");

        if (nome.isEmpty() || dataNascimento.isEmpty() || matricula.isEmpty() ||
            email.isEmpty() || telefone.isEmpty() || endereco.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Todos os campos são obrigatórios!");
            return;
        }

        if (!isValidEmail(email)) {
            JOptionPane.showMessageDialog(this, "Formato de e-mail inválido!");
            return;
        }

        Aluno aluno = new Aluno(nome, dataNascimento, matricula, email, telefone, endereco);
        alunos.add(aluno);
        JOptionPane.showMessageDialog(this, "Aluno cadastrado com sucesso!");
    }

    private void exibirAlunos() {
        StringBuilder sb = new StringBuilder();
        for (Aluno aluno : alunos) {
            sb.append("Nome: ").append(aluno.getNome()).append("\n")
              .append("Data de Nascimento: ").append(aluno.getDataNascimento()).append("\n")
              .append("Matrícula: ").append(aluno.getMatricula()).append("\n")
              .append("E-mail: ").append(aluno.getEmail()).append("\n")
              .append("Telefone: ").append(aluno.getTelefone()).append("\n")
              .append("Endereço: ").append(aluno.getEndereco()).append("\n")
              .append("----------------------\n");
        }
        textArea.setText(sb.toString());
    }

    private void editarAluno() {
        String matricula = JOptionPane.showInputDialog("Digite o número de matrícula do aluno a ser editado:");
        Aluno aluno = encontrarAluno(matricula);
        if (aluno == null) {
            JOptionPane.showMessageDialog(this, "Aluno não encontrado!");
            return;
        }

        String novoNome = JOptionPane.showInputDialog("Novo Nome:", aluno.getNome());
        String novaDataNascimento = JOptionPane.showInputDialog("Nova Data de Nascimento:", aluno.getDataNascimento());
        String novoEmail = JOptionPane.showInputDialog("Novo E-mail:", aluno.getEmail());
        String novoTelefone = JOptionPane.showInputDialog("Novo Telefone:", aluno.getTelefone());
        String novoEndereco = JOptionPane.showInputDialog("Novo Endereço:", aluno.getEndereco());

        if (!novoEmail.isEmpty() && !isValidEmail(novoEmail)) {
            JOptionPane.showMessageDialog(this, "Formato de e-mail inválido!");
            return;
        }

        aluno.setNome(novoNome);
        aluno.setDataNascimento(novaDataNascimento);
        aluno.setEmail(novoEmail);
        aluno.setTelefone(novoTelefone);
        aluno.setEndereco(novoEndereco);

        JOptionPane.showMessageDialog(this, "Dados atualizados com sucesso!");
    }

    private void excluirAluno() {
        String matricula = JOptionPane.showInputDialog("Digite o número de matrícula do aluno a ser excluído:");
        Aluno aluno = encontrarAluno(matricula);
        if (aluno == null) {
            JOptionPane.showMessageDialog(this, "Aluno não encontrado!");
            return;
        }

        int resposta = JOptionPane.showConfirmDialog(this, "Tem certeza que deseja excluir o aluno " + aluno.getNome() + "?",
                "Confirmação", JOptionPane.YES_NO_OPTION);
        if (resposta == JOptionPane.YES_OPTION) {
            alunos.remove(aluno);
            JOptionPane.showMessageDialog(this, "Aluno excluído com sucesso!");
        }
    }

    private Aluno encontrarAluno(String matricula) {
        for (Aluno aluno : alunos) {
            if (aluno.getMatricula().equals(matricula)) {
                return aluno;
            }
        }
        return null;
    }

    private boolean isValidEmail(String email) {
        String emailRegex = "^[a-zA-Z0-9_+&*-]+(?:\\.[a-zA-Z0-9_+&*-]+)*@(?:[a-zA-Z0-9-]+\\.)+[a-zA-Z]{2,7}$";
        Pattern pattern = Pattern.compile(emailRegex);
        return pattern.matcher(email).matches();
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new Janela().setVisible(true));
    }
}
